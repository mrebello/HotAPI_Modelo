﻿global using Hot;
global using Hot.Extensions;
global using Hot.Extensions.HotLogExtensions;
global using Hot.Loggers;

global using static Hot.Functions;
global using static Hot.HotConfiguration;
global using static Hot.HotConfiguration.config;
global using static Hot.HotLog.log;
